import firebase from "../Config/firebase";
export async function  getAll(buscar){
    return fetch(`http://localhost:3000/productos/`)
    .then((res) => res.json())
}
export async function getById(id,token){
    return fetch(`http://localhost:3000/productos/${id}`,{
        headers:{
            "x-access-token":token
        }
    })
    .then((res) => res.json())
}
export function getDescription(id){
    return fetch(`https://api.mercadolibre.com/items/${id}/description`)
    .then((res) => res.json())
}
export async function create(data){
    return await firebase
        .firestore()
        .collection("productos")
        .add(data);
}
export async function update(id,data){
    return await firebase.firestore().doc(`productos/${id}`)
    .set(data)
}
export async function remove(id){
    return await firebase.firestore().doc(`productos/${id}`).delete()
}