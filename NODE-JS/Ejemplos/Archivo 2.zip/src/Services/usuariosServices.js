import firebase from "../Config/firebase";

export function create(payload){
    return fetch("http://localhost:3000/users/",{
        method:"POST",
        headers:{
            'content-type':'application/json'
        },
        body:JSON.stringify(payload)
    }).then(res=>res.json())
}

export function login(payload){
    return fetch("http://localhost:3000/users/login",{
        method:"POST",
        headers:{
            'content-type':'application/json'
        },
        body:JSON.stringify(payload)
    }).then(res=>res.json())
}

export async function getByUserId(userId){
    return await firebase.firestore().collection(`usuarios`)
    .where("userId","==",userId)
    .get()
}