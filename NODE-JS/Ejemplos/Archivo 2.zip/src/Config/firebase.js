import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_AUTH_DOMAIN,
  projectId: "dr20224",
  storageBucket: "dr20224.appspot.com",
  messagingSenderId: "857870769873",
  appId: "1:857870769873:web:4103c3a85e9a308d13eff0"
};

firebase.initializeApp(firebaseConfig)

export default firebase
