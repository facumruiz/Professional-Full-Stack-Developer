import React, { useState, useEffect } from "react";
import Producto from "./Producto";
import { getAll } from "../Services/productosServices";
import Row from "react-bootstrap/Row";
import ProductosCarousel from "./ProductosCarousel";
import Loading from "./Loading/Loading";
import { useFetchProducts } from "../Utils/useFetchProducts";

function Productos() {
  const [compra, setCompra] = useState(false);
  const { productos, loading, buscar, setBuscar } = useFetchProducts();

  const handleComprar = () => {
    setCompra(true);
  };

  return (
    <Loading loading={loading}>
      <div className="">
        <h1>Productos</h1>
        <input
          type="text"
          value={buscar}
          onChange={(event) => setBuscar(event.target.value)}
        />
        <Row>
          {productos.map((producto, index) => (
            <Producto
              {...producto}
              key={producto.id}
              id={producto.id}
              comprar={handleComprar}
            />
          ))}
        </Row>
      </div>
    </Loading>
  );
}

export default Productos;
