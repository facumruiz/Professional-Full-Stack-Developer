import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Loading from '../Components/Loading/Loading';
import { getById } from '../Services/productosServices';
import { useAuthContext } from "../Context/AuthContext";

function Detalle() {
  const { productoId } = useParams();
  const [producto, setProducto] = useState({});
  const [loading, setLoading] = useState(true);
  const { token } = useAuthContext();
  console.log("🚀 ~ file: Detalle.jsx:12 ~ Detalle ~ token:", token)

  const test = 1;

  useEffect(() => {
    const request = async () => {
      try {
        if(token){
          const responseProducto = await getById(productoId,token);

          setProducto(responseProducto);
          setLoading(false);
        }
        
      } catch (e) {
        console.log(e);
      }
    };
    console.log(test);
    request();
  }, [productoId, token]);
  if(token!==""){
    return (
      <Loading loading={loading}>
        <div>
          <h1>{producto.name}</h1>
          <p>{producto.description}</p>
          <p>$ {producto.price}</p>
          <img src={producto.thumbnail} alt="" />
          <p>{producto?.warranty}</p>
        </div>
      </Loading>
    );
  }else{
    return(
      <div>Debe autenticarse para ver el detalle</div>
    )
  }


  
}

export default Detalle;
