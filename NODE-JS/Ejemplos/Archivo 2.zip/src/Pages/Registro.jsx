import { useForm } from 'react-hook-form';
import Input from '../Components/Input';
import { Button, Form } from 'react-bootstrap';
import firebase from '../Config/firebase';
import { useState } from 'react';
import AlertCustom from '../Components/AlertCustom';
import ButtonWithLoading from '../Components/ButtonWithLoading';
import { registroMessage } from '../Utils/errorMessage';
import { create } from '../Services/usuariosServices';

function Registro() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ mode: 'onChange' });
  const [alert, setAlert] = useState({ variant: '', text: '' });
  const [loading, setLoading] = useState(false);

  const onSubmit = async (data) => {
    setLoading(true);
    console.log(data);
    try {
      const document = await create(data)
      if (document) {
        setAlert({
          variant: 'success',
          text: 'Gracias por registrarse',
          duration: 3000,
          link: '/ingresar',
        });
        setLoading(false);
      }
    } catch (e) {
      setAlert({ variant: 'danger', text: registroMessage[e.code] || 'Ha ocurrido un error' });
      setLoading(false);
    }
  };

  return (
    <div>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Input label="Nombre" register={{ ...register('name', { required: true }) }} />
        {errors.name && (
          <div>
            <span>This field is required</span>
          </div>
        )}

        <Input label="Apellido" register={{ ...register('apellido') }} />

        <Input label="Email" type="email" register={{ ...register('email', { required: true }) }} />
        {errors.email && (
          <div>
            <span>This field is required</span>
          </div>
        )}
        <Input
          label="Contraseña"
          type="password"
          register={{
            ...register('password', { required: true, minLength: 1 }),
          }}
        />
        {errors.password && (
          <div>
            {errors.password?.type === 'required' && <span>This field is required</span>}
            {errors.password?.type === 'minLength' && (
              <span>Debe completar al menos 6 caracteres</span>
            )}
          </div>
        )}

        <ButtonWithLoading type="submit" variant="primary" loading={loading}>
          Registrarse
        </ButtonWithLoading>
      </Form>
      <AlertCustom
        // variant={alert.variant}
        // text={alert.text}
        // duration={alert.duration}
        // link={alert.link}
        {...alert}
      />
    </div>
  );
}

export default Registro;
