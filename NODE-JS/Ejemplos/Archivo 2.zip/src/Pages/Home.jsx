import Productos from "../Components/Productos";
import firebase from "../Config/firebase";
import home from "./home.module.css";

function Home() {
  console.log("firebase");
  console.log(firebase);
  return (
    <>
      <div className={home.carousel}>Carousel</div>
      <Productos />
      <div className="">Banners</div>
    </>
  );
}

export default Home;
