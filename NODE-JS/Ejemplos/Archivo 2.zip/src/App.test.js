import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const footer = screen.getByText(/Footer/i);
  expect(footer).toBeInTheDocument();

  const container = screen.getByTestId('app')
  expect(container).toBeVisible()
});
