import { Routes, Route } from "react-router-dom";

import Registro from "../Pages/Registro";
import Login from "../Pages/Login";
import NavBar from "../Components/NavBar";
import Home from "../Pages/Home";
import Contador from "../Pages/Contador";
import Detalle from "../Pages/Detalle";
import Container from "react-bootstrap/Container";
import ProductosAlta from "../Pages/ProductosAlta";
import ProductosModificar from "../Pages/ProductosModificar";
import AuthProvider from "../Context/AuthContext";

function Public() {
  return (
    <>
      <AuthProvider>
        <NavBar />
        <Container>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/alta" element={<Registro />} />
            <Route path="/ingresar" element={<Login />} />
            <Route path="/contador" element={<Contador />} />
            <Route path="/producto/alta" element={<ProductosAlta />} />
            <Route
              path="/producto/editar/:productoId"
              element={<ProductosModificar />}
            />
            <Route path="/producto/:productoId" element={<Detalle />} />
          </Routes>
        </Container>
      </AuthProvider>
    </>
  );
}

export default Public;
