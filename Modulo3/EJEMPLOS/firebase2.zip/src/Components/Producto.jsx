import React from "react"
import { Link } from "react-router-dom"

function Producto({
  id,
  name,
  description,
  price,
  category_id,
  image
}){
  return (
      <div>
        <h2>{name}</h2>
        <img src={image}></img>
        <p>{description}</p>
        <p>{price}</p>
        <p>{category_id}</p>
        
        <button><Link to={`/producto/${id}`}>Ver Detalle</Link></button>
        <button><Link to={`/producto/editar/${id}`}>Editar</Link></button>
      </div>
  )
}

export default Producto
