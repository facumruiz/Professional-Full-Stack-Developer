import React,{Component} from 'react';

class Banner extends Component{
    render(){
        return(
            <div>Banner</div>
        )
    }
}

export default Banner